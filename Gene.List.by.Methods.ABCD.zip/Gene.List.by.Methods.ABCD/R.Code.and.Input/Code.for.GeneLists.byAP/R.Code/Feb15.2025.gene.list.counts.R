######################################
# Create summary of gene counts found by each method

TSG.methodA = read.csv("Feb15.2025.BRCA.TSG.methodA.gene.list.csv")
TSG.methodB = read.csv("Feb15.2025.BRCA.TSG.methodB.gene.list.csv")
TSG.methodC = read.csv("Feb15.2025.BRCA.TSG.methodC.gene.list.csv")
TSG.methodD = read.csv("Feb15.2025.BRCA.TSG.methodD.gene.list.csv")

nonTSG.methodA = read.csv("Feb15.2025.BRCA.nonTSG.methodA.gene.list.csv")
nonTSG.methodB = read.csv("Feb15.2025.BRCA.nonTSG.methodB.gene.list.csv")
nonTSG.methodC = read.csv("Feb15.2025.BRCA.nonTSG.methodC.gene.list.csv")
nonTSG.methodD = read.csv("Feb15.2025.BRCA.nonTSG.methodD.gene.list.csv")

TSG = c(dim(TSG.methodA)[1], dim(TSG.methodB)[1], dim(TSG.methodC)[1], dim(TSG.methodD)[1])
nonTSG = c(dim(nonTSG.methodA)[1], dim(nonTSG.methodB)[1], dim(nonTSG.methodC)[1], dim(nonTSG.methodD)[1])

method = c("A", "B", "C", "D")

gene.list.counts = cbind(method, TSG, nonTSG)
gene.list.counts

write.csv(gene.list.counts, "Feb15.2025.gene.list.counts.csv")