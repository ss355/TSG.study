###########################################################################################
# File: /gpfs/home/udb4/R.code/Correlation/July30.2022.8x8.table5.overlapping.genes.TSG.vs.non.R
###########################################################################################
### Purpose:
# Finds the CG sites and genes corresponding to various areas of table 5

### Usage notes:
# Run once per corerlation matrix DM type (Alive Only DM, Dead Only DM, Overlap DM) per data type (TSG Alive, TSG Dead, HK Alive, HK Dead)

### Input:
#	[1]	Normal DM x DM correlation matrix
#	[2]	Normal DM x nonDM correlation matrix
#	[3]	Tumor DM x DM correlation matrix
#	[4]	Tumor DM x nonDM correlation matrix
#	[5]	gene.type ("HK" or "TSG")
#	[5]	key.word
#	[6]	date

### Usage example:
# R CMD BATCH '--args /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Alive.TSG.AliveOnly.table5.csv /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Alive.TSG.DeadOnly.table5.csv /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Alive.TSG.Overlap.table5.csv /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Dead.TSG.AliveOnly.table5.csv /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Dead.TSG.DeadOnly.table5.csv /gpfs/home/udb4/Results/New.data.correlation/June17.2022.table5.fixed/June20.2022.BRCA.Dead.TSG.Overlap.table5.csv TSG July21.2022' /gpfs/home/udb4/R.code/Correlation/July15.2022.8x8.table5.heatmap.R July15.TSG.table5.heatmap.Rout

### Output:
#	[1-6]	CG.info (for given gene, and for non-given gene)
#	[7-12]	gene.info (for given gene, and for non-given gene)	

###########################################################################################
# Input data
###########################################################################################
date()
args <- commandArgs(trailingOnly = TRUE)
print(args)

DM.info <- read.table(args[1], header=T, sep="\t")
dim(DM.info)
date()

nonDM.info <- read.table(args[2], header=T, sep="\t")
dim(nonDM.info)
date()

normal.DM.corr <- as.matrix(read.table(args[3], header=T, sep="\t"))
dim(normal.DM.corr)
date()

normal.nonDM.corr <- as.matrix(read.table(args[4], header=T, sep="\t"))
dim(normal.nonDM.corr)
date()

tumor.DM.corr <- as.matrix(read.table(args[5], header=T, sep="\t"))
dim(tumor.DM.corr)
date()

tumor.nonDM.corr <- as.matrix(read.table(args[6], header=T, sep="\t"))
dim(tumor.nonDM.corr)
date()

gene.type <- args[7]
gene.type

key.word <- args[8]
key.word

date <- args[9]
date

all.CG.gene.info <- read.table("/home/udb4/Data/Oct22.2021.Data/T2.Oct22.2021.BRCA.AT.391459cg.75col.data.gene.types.methy.state.txt", header=T, sep="\t")
dim(all.CG.gene.info)
# TSG gene names in column 72, HK gene names in column 70
# Genes seperated by ;
all.CG.gene.info[1:2,]
date()

all.overall.CG.gene.info <- read.table("/gpfs/home/udb4/Data/Gene.data/gene.info.391459cg.10col.txt", header=T, sep="\t")
dim(all.overall.CG.gene.info)
# Gene names in column 5
# Genes seperated by ";"
all.overall.CG.gene.info[1:2,]

save.image()

###########################################################################################
# Extract CG/gene info for given gene.type
###########################################################################################
if(gene.type=="TSG")
{
	CG.gene.info <- noquote(cbind(as.character(all.CG.gene.info[,1]), as.character(all.CG.gene.info[,72])))
	colnames(CG.gene.info) <- colnames(all.CG.gene.info)[c(1,72)]
} else if(gene.type =="HK"){
	CG.gene.info <- noquote(cbind(as.character(all.CG.gene.info[,1]), as.character(all.CG.gene.info[,70])))
	colnames(CG.gene.info) <- colnames(all.CG.gene.info)[c(1,70)]
}

CG.gene.info[1:5,]

###########################################################################################
# Extract list of non TSG/HK genes
###########################################################################################
`%!in%` <- Negate(`%in%`)

non.CG.gene.info <- NULL
for(i in 1:dim(all.overall.CG.gene.info)[1])
{
	if(as.character(CG.gene.info[i,1]) != as.character(all.overall.CG.gene.info[i,1]))
	{
		print("For i=", i, " CG sites do not match")
	}
	given.genes <- unlist(strsplit(as.character(CG.gene.info[i,2]), split=";"))
	all.genes <- unlist(strsplit(as.character(all.overall.CG.gene.info[i,5]), split=";"))

	# Find which all.genes are not found in given.genes
	non.given.genes.all <- all.genes[all.genes%!in%given.genes]

	# Remove blank genes "-" and "."
	non.given.genes <- unique(non.given.genes.all[which(non.given.genes.all != "." & non.given.genes.all != "-")])

	if(length(non.given.genes) >= 1)
	{
		non.given.genes.pasted <- paste(non.given.genes, collapse=";")
	} else {
		non.given.genes.pasted <- "-"
	}
	non.CG.gene.info <- rbind(non.CG.gene.info, c(as.character(all.overall.CG.gene.info[i,1]), non.given.genes.pasted))
}

###########################################################################################
# Remove duplicate and self correaltions from DM x DM correlation matrix
###########################################################################################
normal.DM.corr[upper.tri(normal.DM.corr)] <- NA
diag(normal.DM.corr) <- NA	
print(normal.DM.corr[1:5, 1:5])
date()

tumor.DM.corr[upper.tri(tumor.DM.corr)] <- NA
diag(tumor.DM.corr) <- NA
print(tumor.DM.corr[1:5, 1:5])
date()

###########################################################################################
# Combine DM x DM and DM x nonDM, add row/colnames
###########################################################################################
overall.normal.corr <- cbind(normal.DM.corr, normal.nonDM.corr)
dim(overall.normal.corr)
date()

overall.tumor.corr <- cbind(tumor.DM.corr, tumor.nonDM.corr)
dim(overall.tumor.corr)
date()

rownames(overall.normal.corr) <- as.character(DM.info[,1])
rownames(overall.tumor.corr) <- as.character(DM.info[,1])

colnames(overall.normal.corr) <- c(as.character(DM.info[,1]), as.character(nonDM.info[,1]))
colnames(overall.tumor.corr) <- c(as.character(DM.info[,1]), as.character(nonDM.info[,1]))
###########################################################################################
# Create function to find CG sites of interest
###########################################################################################
find.CG.of.interest <- function(normal.corr, tumor.corr, interest.type)
{
	##### Determine which correlation ranges to look for based on interest.type & extract index
	if(interest.type==1) {

		# Highly negative in normal --> Highly positive in tumor
		# Normal [-1, 0.75) --> Tumor [0.5, 1)

		normal.CG.index <- which(normal.corr >= -1 & normal.corr < -0.75)
		tumor.CG.index <- which(tumor.corr >= 0.5 & tumor.corr < 1)

	} else if(interest.type==2) {

		# Highly positive in normal --> Highly negative in tumor
		# Normal [0.75, 1) --> Tumor [-1, -0.5)

		normal.CG.index <- which(normal.corr >= 0.75 & normal.corr < 1)
		tumor.CG.index <- which(tumor.corr >= -1 & tumor.corr < -0.5)

	} else if(interest.type==3) {

		# "Sleeping" in normal --> Highly negative in tumor
		# Normal [-0.25, 0.25] --> Tumor [-1, -0.75)

		normal.CG.index <- which(normal.corr >= -0.25 & normal.corr <= 0.25)
		tumor.CG.index <- which(tumor.corr >= -1 & tumor.corr < -0.75)

	} else if(interest.type==4) {

		# "Sleeping" in normal --> Highly positive in tumor
		# Normal [-0.25, 0.25] --> Tumor [0.75, 1)
	
		normal.CG.index <- which(normal.corr >= -0.25 & normal.corr <= 0.25)
		tumor.CG.index <- which(tumor.corr >= 0.75 & tumor.corr < 1)

	} else if(interest.type==5) {
		# "Shutting-down" negative in normal --> tumor
		# Normal [-1, -0.75) --> Tumor [-0.1, -0.1]

		normal.CG.index <- which(normal.corr >= -1 & normal.corr < -0.75)
		tumor.CG.index <- which (tumor.corr >= -0.1 & tumor.corr <= 0.1)

	} else if(interest.type==6) {

		# "Shutting-down" positive in normal --> tumor
		# Normal [0.75, 1) --> Tumor [-0.1, 0.1]

		normal.CG.index <- which(normal.corr >= 0.75 & normal.corr < 1)
		tumor.CG.index <- which(tumor.corr >= -0.1 & tumor.corr <= 0.1)
	}
	print(paste("Time after normal and tumor indexing: ", date()))

	##### Find overlap between normal and tumor indexes
	overall.index <- normal.CG.index[normal.CG.index%in%tumor.CG.index]
	print(paste("Overall.index length: ", length(overall.index), "   Time: ", date()))

	##### Find which CG sites correlate with the index
	# The overall.index is a one-dimensional index that starts with 1 and goes down each column subsequently

	# To find which row each index is correalted with, we need to find the remainder when dividing by the number of rows
	num.rows <- dim(normal.corr)[1]
	print(paste("Number of rows in corrleation matrix: ", num.rows))
	row.index <- overall.index%%num.rows

	# If the remainder is 0, that means it is in the last row
	row.index[which(row.index==0)] <- num.rows

	# Then we can find which columns are involved
	col.index <- ((overall.index - row.index) / num.rows) + 1

	# Finally we can extract the CG sites associated with each row and column
	row.CG <- as.character(rownames(normal.corr)[row.index])
	col.CG <- as.character(colnames(normal.corr)[col.index])

	##### Combine row and column CG & output
	overall.CG <- cbind(row.CG, col.CG)
	print(paste("Overall.CG length: ", length(overall.CG)))
	return(overall.CG)
}

###########################################################################################
# Use function to find associated CG sites
###########################################################################################
#### Type of interest key
# [1] Highly negative in normal --> Highly positive in tumor
#	Normal [-1, 0.75) --> Tumor [0.5, 1)

# [2] Highly positive in normal --> Highly negative in tumor
	# Normal [0.75, 1) --> Tumor [-1, -0.5)

# [3] "Sleeping" in normal --> Highly negative in tumor
	# Normal [-0.25, 0.25] --> Tumor [-1, -0.75)

# [4] "Sleeping" in normal --> Highly positive in tumor
	# Normal [-0.25, 0.25] --> Tumor [0.75, 1)

# [5] "Shutting-down" negative in normal --> tumor
	# Normal [-1, -0.75) --> Tumor [-0.1, -0.1]

# [6] "Shutting-down" positive in normal --> tumor
	# Normal [0.75, 1) --> Tumor [-0.1, 0.1]

#### Tumor:
negative.normal.positive.tumor <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 1)
positive.normal.negative.normal <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 2)

sleeping.normal.negative.tumor <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 3)
sleeping.normal.positive.tumor <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 4)

shutdown.negative.normal <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 5)
shutdown.positive.normal <- find.CG.of.interest(overall.normal.corr, overall.tumor.corr, 6)

###########################################################################################
# Create function to find CG site counts and gene info counts
###########################################################################################
find.CG.info <- function(CG.sites, gene.info)
{
	# Combine CG sites
	all.CG.sites <- c(as.character(CG.sites[,1]), as.character(CG.sites[,2]))

	# Create frequency table for CG sites
	CG.counts <- data.frame(table(all.CG.sites))
	colnames(CG.counts) <- c("CG.site", "Freq")

	# Extract genes
	gene.index <- gene.info[,1]%in%CG.counts[,1]
	CG.genes.of.int <- gene.info[gene.index, ]

	# Sort frequency table & gene info table alphabetically
	CG.counts.sorted <- CG.counts[order(CG.counts[,1],decreasing=FALSE),]
	CG.genes.of.int.sorted <- CG.genes.of.int[order(CG.genes.of.int[,1],decreasing=FALSE),]

	# Combine frequency table with genes
	overall.CG.info <- cbind(CG.counts.sorted, CG.genes.of.int[,2])
	colnames(overall.CG.info) <- c("CG.site", "Freq", "Genes")

	return(overall.CG.info)
}

###########################################################################################
# Find CG site counts and gene info counts for given gene
###########################################################################################
#### Use function
negative.normal.positive.tumor.info <- find.CG.info(negative.normal.positive.tumor, CG.gene.info)
positive.normal.negative.normal.info <- find.CG.info(positive.normal.negative.normal, CG.gene.info)

sleeping.normal.negative.tumor.info <- find.CG.info(sleeping.normal.negative.tumor, CG.gene.info)
sleeping.normal.positive.tumor.info <- find.CG.info(sleeping.normal.positive.tumor, CG.gene.info)

shutdown.negative.normal.info <- find.CG.info(shutdown.negative.normal, CG.gene.info)
shutdown.positive.normal.info <- find.CG.info(shutdown.positive.normal, CG.gene.info)


#### Output results
corr.group.names <- c("negative.normal.positive.tumor", "positive.normal.negative.normal", 
			"sleeping.normal.negative.tumor", "sleeping.normal.positive.tumor",
			"shutdown.negative.normal", "shutdown.positive.normal")

CG.info.names <- paste(date, key.word, corr.group.names, "CG.info.csv", sep=".")
CG.info.names

write.table(negative.normal.positive.tumor.info, file=CG.info.names[1], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(positive.normal.negative.normal.info, file=CG.info.names[2], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(sleeping.normal.negative.tumor.info, file=CG.info.names[3], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(sleeping.normal.positive.tumor.info, file=CG.info.names[4], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(shutdown.negative.normal.info, file=CG.info.names[5], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(shutdown.positive.normal.info, file=CG.info.names[6], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)


###########################################################################################
# Find CG site counts and gene info counts for non-given gene
###########################################################################################
#### Use function
negative.normal.positive.tumor.info.non <- find.CG.info(negative.normal.positive.tumor, non.CG.gene.info)
positive.normal.negative.normal.info.non <- find.CG.info(positive.normal.negative.normal, non.CG.gene.info)

sleeping.normal.negative.tumor.info.non <- find.CG.info(sleeping.normal.negative.tumor, non.CG.gene.info)
sleeping.normal.positive.tumor.info.non <- find.CG.info(sleeping.normal.positive.tumor, non.CG.gene.info)

shutdown.negative.normal.info.non <- find.CG.info(shutdown.negative.normal, non.CG.gene.info)
shutdown.positive.normal.info.non <- find.CG.info(shutdown.positive.normal, non.CG.gene.info)


#### Output results
corr.group.names <- c("negative.normal.positive.tumor", "positive.normal.negative.normal", 
			"sleeping.normal.negative.tumor", "sleeping.normal.positive.tumor",
			"shutdown.negative.normal", "shutdown.positive.normal")

non.CG.info.names <- paste(date, "non", key.word, corr.group.names, "CG.info.csv", sep=".")
non.CG.info.names

write.table(negative.normal.positive.tumor.info.non, file=non.CG.info.names[1], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(positive.normal.negative.normal.info.non, file=non.CG.info.names[2], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(sleeping.normal.negative.tumor.info.non, file=non.CG.info.names[3], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(sleeping.normal.positive.tumor.info.non, file=non.CG.info.names[4], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(shutdown.negative.normal.info.non, file=non.CG.info.names[5], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(shutdown.positive.normal.info.non, file=non.CG.info.names[6], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)


###########################################################################################
# Create function to find gene info
###########################################################################################
seperate.extracted <- function(xrow)
{
	# Takes in one row of extracted data and creates one line per gene instead of per CG site
	# For use in apply
	
	# Extract CG site and gene names
	CG.site.info <- c(as.character(xrow[1]), xrow[2])
	final.output <- NULL
	gene.names <- unique(unlist(strsplit(as.character(xrow[3]), split=";")))
	for(i in 1:length(gene.names))
	{
		new.line <- c(as.character(gene.names[i]), CG.site.info)
		final.output <- c(final.output, new.line)
	}	
	
	# Remove rownames and return final output
	rownames(final.output) <- NULL
	return(final.output)
}

find.gene.info <- function(CG.gene.info)
{
	# Create one row per gene/CG
	CG.data.seperated.raw <- matrix(unlist(apply(CG.gene.info, 1, seperate.extracted)), ncol=3, byrow=T)
	colnames(CG.data.seperated.raw) <- c("gene", "CG.site", "CG.count")
	print("CG.data.seperated.raw")
	print(CG.data.seperated.raw[1:3,])

	# Remove blank genes ("-")
	not.blank.index <- which(CG.data.seperated.raw[,1]!="-")
	CG.data.seperated <- CG.data.seperated.raw[not.blank.index, ]
	print("CG.data.seperated")
	print(CG.data.seperated[1:3,])

	gene.freq <- as.data.frame(table(CG.data.seperated[,1]))
	colnames(gene.freq) <- c("Gene", "Freq")

	gene.freq.sorted <- gene.freq[order(gene.freq[,2],decreasing=TRUE),]
	return(gene.freq.sorted)
}

###########################################################################################
# Find gene info for given gene
###########################################################################################
negative.normal.positive.tumor.genes <- find.gene.info(negative.normal.positive.tumor.info)
negative.normal.positive.tumor.genes[1:5,]
positive.normal.negative.normal.genes <- find.gene.info(positive.normal.negative.normal.info)
positive.normal.negative.normal.genes[1:5,]

sleeping.normal.negative.tumor.genes <- find.gene.info(sleeping.normal.negative.tumor.info)
sleeping.normal.negative.tumor.genes[1:5,]
sleeping.normal.positive.tumor.genes <- find.gene.info(sleeping.normal.positive.tumor.info)
sleeping.normal.positive.tumor.genes[1:5,]

shutdown.negative.normal.genes <- find.gene.info(shutdown.negative.normal.info)
shutdown.negative.normal.genes[1:5,]
shutdown.positive.normal.genes <- find.gene.info(shutdown.positive.normal.info)
shutdown.positive.normal.genes[1:5,]

#### Output results
gene.info.names <- paste(date, key.word, corr.group.names, "gene.info.csv", sep=".")
gene.info.names

write.table(negative.normal.positive.tumor.genes, file=gene.info.names[1], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(positive.normal.negative.normal.genes, file=gene.info.names[2], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(sleeping.normal.negative.tumor.genes, file=gene.info.names[3], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(sleeping.normal.positive.tumor.genes, file=gene.info.names[4], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(shutdown.negative.normal.genes, file=gene.info.names[5], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(shutdown.positive.normal.genes, file=gene.info.names[6], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

###########################################################################################
# Find gene info for non-given gene
###########################################################################################
negative.normal.positive.tumor.genes.non <- find.gene.info(negative.normal.positive.tumor.info.non)
negative.normal.positive.tumor.genes.non[1:5,]
positive.normal.negative.normal.genes.non <- find.gene.info(positive.normal.negative.normal.info.non)
positive.normal.negative.normal.genes.non[1:5,]

sleeping.normal.negative.tumor.genes.non <- find.gene.info(sleeping.normal.negative.tumor.info.non)
sleeping.normal.negative.tumor.genes.non[1:5,]
sleeping.normal.positive.tumor.genes.non <- find.gene.info(sleeping.normal.positive.tumor.info.non)
sleeping.normal.positive.tumor.genes.non[1:5,]

shutdown.negative.normal.genes.non <- find.gene.info(shutdown.negative.normal.info.non)
shutdown.negative.normal.genes.non[1:5,]
shutdown.positive.normal.genes.non <- find.gene.info(shutdown.positive.normal.info.non)
shutdown.positive.normal.genes.non[1:5,]

#### Output results
gene.info.names.non <- paste(date, "non", key.word, corr.group.names, "gene.info.csv", sep=".")
gene.info.names.non

write.table(negative.normal.positive.tumor.genes.non, file=gene.info.names.non[1], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(positive.normal.negative.normal.genes.non, file=gene.info.names.non[2], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(sleeping.normal.negative.tumor.genes.non, file=gene.info.names.non[3], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(sleeping.normal.positive.tumor.genes.non, file=gene.info.names.non[4], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

write.table(shutdown.negative.normal.genes.non, file=gene.info.names.non[5], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)
write.table(shutdown.positive.normal.genes.non, file=gene.info.names.non[6], row.names=FALSE, col.names=TRUE, sep=",", quote=FALSE)

###########################################################################################
# Find number of unique CG sites and unique genes for each group for given genes
###########################################################################################
find.total.unique <- function(CG.info, gene.info)
{
	total.CG <- dim(CG.info)[1]
	total.gene <- dim(gene.info)[1]

	return(rbind(total.CG, total.gene))
}

overall.total <- cbind(find.total.unique(negative.normal.positive.tumor.info, negative.normal.positive.tumor.genes), 
			find.total.unique(positive.normal.negative.normal.info, positive.normal.negative.normal.genes),
			find.total.unique(sleeping.normal.negative.tumor.info, sleeping.normal.negative.tumor.genes), 
			find.total.unique(sleeping.normal.positive.tumor.info, sleeping.normal.positive.tumor.genes),
			find.total.unique(shutdown.negative.normal.info, shutdown.negative.normal.genes), 
			find.total.unique(shutdown.positive.normal.info, shutdown.positive.normal.genes))
overall.total
colnames(overall.total) <- corr.group.names
rownames(overall.total) <- c("Unique.CG.count", "Unique.Gene.count")

overall.total.name <- paste(date, key.word, "CG.and.gene.counts.csv", sep=".")

write.table(overall.total, file=overall.total.name, sep=",", quote=FALSE, row.names=TRUE, col.names=TRUE)

###########################################################################################
# Find number of unique CG sites and unique genes for each group for non-given genes
###########################################################################################
overall.total.non <- cbind(find.total.unique(negative.normal.positive.tumor.info.non, negative.normal.positive.tumor.genes.non), 
			find.total.unique(positive.normal.negative.normal.info.non, positive.normal.negative.normal.genes.non),
			find.total.unique(sleeping.normal.negative.tumor.info.non, sleeping.normal.negative.tumor.genes.non), 
			find.total.unique(sleeping.normal.positive.tumor.info.non, sleeping.normal.positive.tumor.genes.non),
			find.total.unique(shutdown.negative.normal.info.non, shutdown.negative.normal.genes.non), 
			find.total.unique(shutdown.positive.normal.info.non, shutdown.positive.normal.genes.non))
overall.total.non
colnames(overall.total.non) <- corr.group.names
rownames(overall.total.non) <- c("Unique.CG.count", "Unique.Gene.count")

overall.total.name.non <- paste(date, "non", key.word, "CG.and.gene.counts.csv", sep=".")

write.table(overall.total.non, file=overall.total.name.non, sep=",", quote=FALSE, row.names=TRUE, col.names=TRUE)
