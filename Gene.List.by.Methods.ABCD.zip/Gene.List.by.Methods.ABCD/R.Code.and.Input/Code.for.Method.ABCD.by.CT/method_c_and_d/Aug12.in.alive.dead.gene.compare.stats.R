 #############################################
# Aug12.in.alive.dead.gene.compare.stats.R
#############################################
 
args=commandArgs(TRUE)
`%notin%` = Negate(`%in%`)
 
################################
# Transposes gene lists and reformats it so that columns names are genes
transpose.gene.list = function(gene.list){
  new.gene.list=t(gene.list[,2])
  colnames(new.gene.list)=gene.list[,1]
       
  return (new.gene.list)
}
 
################################
# Returns genes that occur in >=min.panels panels with frequencies=min.freq
panel.freq.counts = function(neg2pos, pos2neg, shutting.neg, shutting.pos, sleeping.neg, sleeping.pos, min.panels, min.freq){
       
   all.genes=unique(c(neg2pos[,1], pos2neg[,1], 
                      shutting.neg[,1], shutting.pos[,1],
                      sleeping.neg[,1], sleeping.pos[,1]))
   #print('SSTR5' %in% all.genes)
   gene.panel.info=data.frame()
         
   for (gene in all.genes){
        panels.present.name=''
        alive.counts=''
        dead.counts=''
        panels.present.count=0
               
        #Finds the panels that the gene is present in
         if (gene %in% neg2pos){
             if (as.numeric(neg2pos[neg2pos[,1]==gene, 2])>=min.freq & as.numeric(neg2pos[neg2pos[,1]==gene, 3])>=min.freq){
                 panels.present.name=paste(panels.present.name,'neg2pos',sep=';')
                 panels.present.count=panels.present.count+1
                 alive.counts=paste(alive.counts, neg2pos[neg2pos[,1]==gene, 2], sep=';')
                 dead.counts=paste(dead.counts, neg2pos[neg2pos[,1]==gene, 3], sep=';')
              }
          } 
          if (gene %in% pos2neg){
              if (as.numeric(pos2neg[pos2neg[,1]==gene, 2])>=min.freq & as.numeric(pos2neg[pos2neg[,1]==gene, 3])>=min.freq){
                  panels.present.name=paste(panels.present.name,'pos2neg',sep=';')
                  panels.present.count=panels.present.count+1
                  alive.counts=paste(alive.counts, pos2neg[pos2neg[,1]==gene, 2], sep=';')
                  dead.counts=paste(dead.counts, pos2neg[pos2neg[,1]==gene, 3], sep=';')
               }
           } 
           if (gene %in% sleeping.neg){
               if(as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 2])>=min.freq & as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 3])>=min.freq){
                   panels.present.name=paste(panels.present.name,'sleeping.neg',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, sleeping.neg[sleeping.neg[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, sleeping.neg[sleeping.neg[,1]==gene, 3], sep=';')
                 }
             } 
           if (gene %in% sleeping.pos){
               if (as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 2])>=min.freq & as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 3])>=min.freq){
                   panels.present.name=paste(panels.present.name,'sleeping.pos',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, sleeping.pos[sleeping.pos[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, sleeping.pos[sleeping.pos[,1]==gene, 3], sep=';')
                 }
             } 

           if (gene %in% shutting.neg){
               if (as.numeric(shutting.neg[shutting.neg[,1]==gene, 2])>=min.freq & as.numeric(shutting.neg[shutting.neg[,1]==gene, 3])>=min.freq){
                   panels.present.name=paste(panels.present.name,'neg.shutting',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, shutting.neg[shutting.neg[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, shutting.neg[shutting.neg[,1]==gene, 3], sep=';')
                 }
             } 
           if (gene %in% shutting.pos){
               if (as.numeric(shutting.pos[shutting.pos[,1]==gene, 2])>=min.freq & as.numeric(shutting.pos[shutting.pos[,1]==gene, 3])>=min.freq){
                   panels.present.name=paste(panels.present.name,'pos.shutting',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, shutting.pos[shutting.pos[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, shutting.pos[shutting.pos[,1]==gene, 3], sep=';')
                 }
             } 
             panels.present.name=substring(panels.present.name, 2)
             alive.counts=substring(alive.counts, 2)
             dead.counts=substring(dead.counts, 2)
               
             #if the panel count is >=min.panels, then the gene and the panels are appended to a matrix
             if (panels.present.count>=min.panels){
                 new.row=cbind(gene, panels.present.name, as.character(panels.present.count), alive.counts, dead.counts)
                 gene.panel.info=rbind(gene.panel.info, new.row)
               }
         }
      colnames(gene.panel.info)=c('Gene', 'panels.present','panel.counts', 'alive.counts', 'dead.counts')
         
      return (gene.panel.info)
}
 
################################
# Returns genes that occur in >=min.panels panels with frequencies=min.diff
panel.freq.large.diff = function(neg2pos, pos2neg, shutting.neg, shutting.pos, sleeping.neg, sleeping.pos, min.panels, min.diff){
       
     all.genes=unique(c(neg2pos[,1], pos2neg[,1], 
                        shutting.neg[,1], shutting.pos[,1],
                        sleeping.neg[,1], sleeping.pos[,1]))
     gene.panel.info=data.frame()
         
     for (gene in all.genes){
         panels.present.name=''
         alive.counts=''
         dead.counts=''
         diff.counts=''
         panels.present.count=0
               
         #Finds the panels that the gene is present in
         if (gene %in% neg2pos){
             if (abs(as.numeric(neg2pos[neg2pos[,1]==gene, 2]) - as.numeric(neg2pos[neg2pos[,1]==gene, 3]))>=min.diff){
                 panels.present.name=paste(panels.present.name,'neg2pos',sep=';')
                 panels.present.count=panels.present.count+1
                 alive.counts=paste(alive.counts, neg2pos[neg2pos[,1]==gene, 2], sep=';')
                 dead.counts=paste(dead.counts, neg2pos[neg2pos[,1]==gene, 3], sep=';')
                 diff.counts=paste(diff.counts, as.numeric(neg2pos[neg2pos[,1]==gene, 3]) - as.numeric(neg2pos[neg2pos[,1]==gene, 2]), sep=';')
               }
           } 
           if (gene %in% pos2neg){
               if (abs(as.numeric(pos2neg[pos2neg[,1]==gene, 2]) - as.numeric(pos2neg[pos2neg[,1]==gene, 3]))>=min.diff){
                   panels.present.name=paste(panels.present.name,'pos2neg',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, pos2neg[pos2neg[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, pos2neg[pos2neg[,1]==gene, 3], sep=';')
                   diff.counts=paste(diff.counts, as.numeric(pos2neg[pos2neg[,1]==gene, 3]) - as.numeric(pos2neg[pos2neg[,1]==gene, 2]), sep=';')
                 }
             } 
           if (gene %in% sleeping.neg){
               if(abs(as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 2]) - as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 3]))>=min.diff){
                   panels.present.name=paste(panels.present.name,'sleeping.neg',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, sleeping.neg[sleeping.neg[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, sleeping.neg[sleeping.neg[,1]==gene, 3], sep=';')
                   diff.counts=paste(diff.counts, as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 3]) - as.numeric(sleeping.neg[sleeping.neg[,1]==gene, 2]), sep=';')
                 }
             } 
           if (gene %in% sleeping.pos){
               if (abs(as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 2]) - as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 3]))>=min.diff){
                   panels.present.name=paste(panels.present.name,'sleeping.pos',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, sleeping.pos[sleeping.pos[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, sleeping.pos[sleeping.pos[,1]==gene, 3], sep=';')
                   diff.counts=paste(diff.counts, as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 3]) - as.numeric(sleeping.pos[sleeping.pos[,1]==gene, 2]), sep=';')
                 }
             } 
           if (gene %in% shutting.neg){
               if (abs(as.numeric(shutting.neg[shutting.neg[,1]==gene, 2]) - as.numeric(shutting.neg[shutting.neg[,1]==gene, 3]))>=min.diff){
                   panels.present.name=paste(panels.present.name,'neg.shutting',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, shutting.neg[shutting.neg[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, shutting.neg[shutting.neg[,1]==gene, 3], sep=';')
                   diff.counts=paste(diff.counts, as.numeric(shutting.neg[shutting.neg[,1]==gene, 3]) - as.numeric(shutting.neg[shutting.neg[,1]==gene, 2]), sep=';')
                 }
             } 
           if (gene %in% shutting.pos){
               if (abs(as.numeric(shutting.pos[shutting.pos[,1]==gene, 2]) - as.numeric(shutting.pos[shutting.pos[,1]==gene, 3]))>=min.diff){
                   panels.present.name=paste(panels.present.name,'pos.shutting',sep=';')
                   panels.present.count=panels.present.count+1
                   alive.counts=paste(alive.counts, shutting.pos[shutting.pos[,1]==gene, 2], sep=';')
                   dead.counts=paste(dead.counts, shutting.pos[shutting.pos[,1]==gene, 3], sep=';')
                   diff.counts=paste(diff.counts, as.numeric(shutting.pos[shutting.pos[,1]==gene, 3]) - as.numeric(shutting.pos[shutting.pos[,1]==gene, 2]), sep=';')
                 }
             } 

             panels.present.name=substring(panels.present.name, 2)
             alive.counts=substring(alive.counts, 2)
             dead.counts=substring(dead.counts, 2)
             diff.counts=substring(diff.counts, 2)
               
             #if the panel count is =min.panels, then the gene and the panels are appended to a matrix
             if (panels.present.count>=min.panels){
                 new.row=cbind(gene, panels.present.name, as.character(panels.present.count), alive.counts, dead.counts, diff.counts)
                 gene.panel.info=rbind(gene.panel.info, new.row)
               }
         }
    colnames(gene.panel.info)=c('Gene', 'panels.present','panel.counts', 'alive.counts', 'dead.counts', 'alive.dead.diff')
         
    return (gene.panel.info)
}
 
################################
# Returns the frequency of a gene in the alive and dead data
alive.dead.freq = function(alive, dead, genes){
   
     freq=cbind(genes, as.numeric(alive[,genes]), as.numeric(dead[,genes]))
     colnames(freq)=c('Gene', 'alive.count', 'dead.count')
     rownames(freq)=NULL
     
      return (freq)
}
 
################################
# Finds genes that appear in >=min.panels panels with counts =freq.min
panel.freq.count.genes = function(alive.neg2pos, alive.pos2neg, alive.shutting.neg, alive.shutting.pos, alive.sleeping.neg, alive.sleeping.pos, 
                                 dead.neg2pos, dead.pos2neg, dead.shutting.neg, dead.shutting.pos, dead.sleeping.neg, dead.sleeping.pos, freq.min, panels.min){
   
     #Combining all the genes from each of the 12 panels into one list
     alive.all.genes= unique(c(as.character(alive.neg2pos[,1]), as.character(alive.pos2neg[,1]), 
                             as.character(alive.shutting.neg[,1]), as.character(alive.shutting.pos[,1]), 
                             as.character(alive.sleeping.neg[,1]), as.character(alive.sleeping.pos[,1])))
     dead.all.genes= unique(c(as.character(dead.neg2pos[,1]), as.character(dead.pos2neg[,1]), 
                            as.character(dead.shutting.neg[,1]), as.character(dead.shutting.pos[,1]), 
                            as.character(dead.sleeping.neg[,1]), as.character(dead.sleeping.pos[,1])))
     genes.in.both=intersect(alive.all.genes, dead.all.genes)
     print('SSTR5' %in% alive.all.genes)
     print('SSTR5' %in% dead.all.genes)
     
     #Remove '.' if present
     genes.in.both=genes.in.both[genes.in.both %notin% '.']
       
     #Transpose
     alive.neg2pos=transpose.gene.list(alive.neg2pos)
     alive.pos2neg=transpose.gene.list(alive.pos2neg)
     alive.shutting.neg=transpose.gene.list(alive.shutting.neg)
     alive.shutting.pos=transpose.gene.list(alive.shutting.pos)
     alive.sleeping.neg=transpose.gene.list(alive.sleeping.neg)
     alive.sleeping.pos=transpose.gene.list(alive.sleeping.pos)
     dead.neg2pos=transpose.gene.list(dead.neg2pos)
     dead.pos2neg=transpose.gene.list(dead.pos2neg)
     dead.shutting.neg=transpose.gene.list(dead.shutting.neg)
     dead.shutting.pos=transpose.gene.list(dead.shutting.pos)
     dead.sleeping.neg=transpose.gene.list(dead.sleeping.neg)
     dead.sleeping.pos=transpose.gene.list(dead.sleeping.pos)
         
     #Finding genes that are in both dead and alive and their frequencies
     neg2pos.dead.alive.genes=alive.dead.freq(alive.neg2pos, dead.neg2pos, genes.in.both[which((genes.in.both %in% colnames(alive.neg2pos)) & (genes.in.both %in% colnames(dead.neg2pos)))])
     
     pos2neg.dead.alive.genes=alive.dead.freq(alive.pos2neg, dead.pos2neg, genes.in.both[which((genes.in.both %in% colnames(alive.pos2neg)) & (genes.in.both %in% colnames(dead.pos2neg)))])
       
     shutting.neg.dead.alive.genes=alive.dead.freq(alive.shutting.neg, dead.shutting.neg, genes.in.both[which((genes.in.both %in% colnames(alive.shutting.neg)) & (genes.in.both %in% colnames(dead.shutting.neg)))])
         
     shutting.pos.dead.alive.genes=alive.dead.freq(alive.shutting.pos, dead.shutting.pos, genes.in.both[which((genes.in.both %in% colnames(alive.shutting.pos)) & (genes.in.both %in% colnames(dead.shutting.pos)))])
           
     sleeping.neg.dead.alive.genes=alive.dead.freq(alive.sleeping.neg, dead.sleeping.neg, genes.in.both[which((genes.in.both %in% colnames(alive.sleeping.neg)) & (genes.in.both %in% colnames(dead.sleeping.neg)))])
             
     sleeping.pos.dead.alive.genes=alive.dead.freq(alive.sleeping.pos, dead.sleeping.pos, genes.in.both[which((genes.in.both %in% colnames(alive.sleeping.pos)) & (genes.in.both %in% colnames(dead.sleeping.pos)))])
               
     #Extracting genes that appear in at least panels.min panels with frequencies =freq.min
     #also extracts the names of the panels that they appear in and the alive and dead freq
     gene.panel.freq.info=panel.freq.counts( neg2pos.dead.alive.genes, pos2neg.dead.alive.genes, 
                                             shutting.neg.dead.alive.genes, shutting.pos.dead.alive.genes,
                                             sleeping.neg.dead.alive.genes, sleeping.pos.dead.alive.genes, panels.min, freq.min)
     gene.panel.freq.info = gene.panel.freq.info[order(gene.panel.freq.info[,3], decreasing=TRUE), ]
     print(dim(gene.panel.freq.info))
     print(gene.panel.freq.info[1:5,])
       
     return (gene.panel.freq.info)
}
 ################################
 # Finds genes that appear in >=min.panels panels and have large differences in freq between alive and dead
panel.freq.diff.genes = function(alive.neg2pos, alive.pos2neg, alive.shutting.neg, alive.shutting.pos, alive.sleeping.neg, alive.sleeping.pos, 
                                                                                          dead.neg2pos, dead.pos2neg, dead.shutting.neg, dead.shutting.pos, dead.sleeping.neg, dead.sleeping.pos, diff.min, panels.min){
  #Combining all the genes from each of the 12 panels into one list
  alive.all.genes= unique(c(as.character(alive.neg2pos[,1]), as.character(alive.pos2neg[,1]), 
                             as.character(alive.shutting.neg[,1]), as.character(alive.shutting.pos[,1]), 
                             as.character(alive.sleeping.neg[,1]), as.character(alive.sleeping.pos[,1])))
  dead.all.genes= unique(c(as.character(dead.neg2pos[,1]), as.character(dead.pos2neg[,1]), 
                            as.character(dead.shutting.neg[,1]), as.character(dead.shutting.pos[,1]), 
                            as.character(dead.sleeping.neg[,1]), as.character(dead.sleeping.pos[,1])))
  genes.in.both=intersect(alive.all.genes, dead.all.genes)
  
  #Remove '.' if present
  genes.in.both=genes.in.both[genes.in.both %notin% '.']
  
  #Transpose
  alive.neg2pos=transpose.gene.list(alive.neg2pos)
  alive.pos2neg=transpose.gene.list(alive.pos2neg)
  alive.shutting.neg=transpose.gene.list(alive.shutting.neg)
  alive.shutting.pos=transpose.gene.list(alive.shutting.pos)
  alive.sleeping.neg=transpose.gene.list(alive.sleeping.neg)
  alive.sleeping.pos=transpose.gene.list(alive.sleeping.pos)
  dead.neg2pos=transpose.gene.list(dead.neg2pos)
  dead.pos2neg=transpose.gene.list(dead.pos2neg)
  dead.shutting.neg=transpose.gene.list(dead.shutting.neg)
  dead.shutting.pos=transpose.gene.list(dead.shutting.pos)
  dead.sleeping.neg=transpose.gene.list(dead.sleeping.neg)
  dead.sleeping.pos=transpose.gene.list(dead.sleeping.pos)
  
  #Finding genes that are in both dead and alive and their frequencies
  neg2pos.dead.alive.genes=alive.dead.freq(alive.neg2pos, dead.neg2pos, genes.in.both[which((genes.in.both %in% colnames(alive.neg2pos)) & (genes.in.both %in% colnames(dead.neg2pos)))])
  
  pos2neg.dead.alive.genes=alive.dead.freq(alive.pos2neg, dead.pos2neg, genes.in.both[which((genes.in.both %in% colnames(alive.pos2neg)) & (genes.in.both %in% colnames(dead.pos2neg)))])
  
  shutting.neg.dead.alive.genes=alive.dead.freq(alive.shutting.neg, dead.shutting.neg, genes.in.both[which((genes.in.both %in% colnames(alive.shutting.neg)) & (genes.in.both %in% colnames(dead.shutting.neg)))])
  
  shutting.pos.dead.alive.genes=alive.dead.freq(alive.shutting.pos, dead.shutting.pos, genes.in.both[which((genes.in.both %in% colnames(alive.shutting.pos)) & (genes.in.both %in% colnames(dead.shutting.pos)))])
  
  sleeping.neg.dead.alive.genes=alive.dead.freq(alive.sleeping.neg, dead.sleeping.neg, genes.in.both[which((genes.in.both %in% colnames(alive.sleeping.neg)) & (genes.in.both %in% colnames(dead.sleeping.neg)))])
  
  sleeping.pos.dead.alive.genes=alive.dead.freq(alive.sleeping.pos, dead.sleeping.pos, genes.in.both[which((genes.in.both %in% colnames(alive.sleeping.pos)) & (genes.in.both %in% colnames(dead.sleeping.pos)))])
  
  #Extracting genes that appear in at least panels.min panels with frequencies >=diff.min
  #also extracts the names of the panels that they appear in and the alive and dead freq
  gene.panel.freq.info=panel.freq.large.diff( neg2pos.dead.alive.genes, pos2neg.dead.alive.genes, 
                                          shutting.neg.dead.alive.genes, shutting.pos.dead.alive.genes,
                                          sleeping.neg.dead.alive.genes, sleeping.pos.dead.alive.genes, panels.min, diff.min)
  gene.panel.freq.info = gene.panel.freq.info[order(gene.panel.freq.info[,3], decreasing=TRUE), ]
  print(dim(gene.panel.freq.info))
  print(gene.panel.freq.info[1:5,])
  
  return (gene.panel.freq.info)
}
 
################################
# Reading in data
# R CMD BATCH '--args nonTSG.gene.lists/Aug12.2022.neg2pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.pos2neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.neg2pos.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.pos2neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.pos.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.pos.dead.overlap.nonTSG.gene.list.csv Aug23.2022 nonTSG.Overlap' /home/c_t370/REU.2021/Code/8x8/Aug12.in.alive.dead.gene.compare.stats.R /home/c_t370/REU.2021/Output/8x8/sleeping.shutting/TSG.Overlap.Common.Genes/Aug12.nonTSG.dead.alive.common.Rout
# R CMD BATCH '--args TSG.only.gene.lists/Aug5.only.TSG.neg2pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.pos2neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.neg2pos.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.pos2neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.pos.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.pos.genes.dead.overlap.csv Aug23.2022 onlyTSG.overlap' /home/c_t370/REU.2021/Code/8x8/Aug12.in.alive.dead.gene.compare.stats.R /home/c_t370/REU.2021/Output/8x8/sleeping.shutting/TSG.Overlap.Common.Genes/Aug12.onlyTSG.dead.alive.common.Rout
   
alive.neg2pos=read.csv(args[1], header=TRUE)
dim(alive.neg2pos)
 
alive.pos2neg=read.csv(args[2], header=TRUE)
dim(alive.pos2neg)

alive.shutting.neg=read.csv(args[3], header=TRUE)
dim(alive.shutting.neg)

alive.shutting.pos=read.csv(args[4], header=TRUE)
dim(alive.shutting.pos)
 
alive.sleeping.neg=read.csv(args[5], header=TRUE)
dim(alive.sleeping.neg)
 
alive.sleeping.pos=read.csv(args[6], header=TRUE)
dim(alive.sleeping.pos)
 
dead.neg2pos=read.csv(args[7], header=TRUE)
dim(dead.neg2pos)
 
dead.pos2neg=read.csv(args[8], header=TRUE)
dim(dead.pos2neg)
 
dead.shutting.neg=read.csv(args[9], header=TRUE)
dim(dead.shutting.neg)
 
dead.shutting.pos=read.csv(args[10], header=TRUE)
dim(dead.shutting.pos)
 
dead.sleeping.neg=read.csv(args[11], header=TRUE)
dim(dead.sleeping.neg)

 
dead.sleeping.pos=read.csv(args[12], header=TRUE)
dim(dead.sleeping.pos)

date=args[13]
print(date)
 
type=args[14]
print(type)

################################
       
output=panel.freq.count.genes(alive.neg2pos, alive.pos2neg, alive.shutting.neg, alive.shutting.pos, alive.sleeping.neg, alive.sleeping.pos, 
                              dead.neg2pos, dead.pos2neg, dead.shutting.neg, dead.shutting.pos, dead.sleeping.neg, dead.sleeping.pos, 3, 4)
write.table(output, paste('TSG.Overlap.Common.Genes/', date,'.', type, 'genes.in.alive.dead.panels', 4, '.freq', 3, '.csv', sep=''), sep=',', row.names=FALSE)
           
output=panel.freq.diff.genes(alive.neg2pos, alive.pos2neg, alive.shutting.neg, alive.shutting.pos, alive.sleeping.neg, alive.sleeping.pos, 
                             dead.neg2pos, dead.pos2neg, dead.shutting.neg, dead.shutting.pos, dead.sleeping.neg, dead.sleeping.pos, 3, 4)
write.table(output, paste('TSG.Overlap.Common.Genes/', date,'.', type, 'genes.in.alive.dead.panels', 4, '.freq.diff', 3, '.csv', sep=''), sep=',', row.names=FALSE)


