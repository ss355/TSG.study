###########################################################################################
# File: /gpfs/home/udb4/R.code/Correlation/August12.2022.overlapping.genes.analysis.R
###########################################################################################
### Purpose:
# Finds overlapping and unique genes between correlation areas

### Usage notes:
# Run once per corerlation matrix DM type (Alive Only DM, Dead Only DM, Overlap DM) per data type (TSG Alive, TSG Dead, HK Alive, HK Dead)

### Input:
#	[1]	Gene correlation panel info
#	[2]	Date
#	[3]	Key.word	

### Output:
#	[1]	Alive and dead overlap in >= 4 panels, N >= 3 (dataset)
#	[2]	|Alive - Dead| >= 3 in >= 4 panels (dataset)
#	[3]	Only Alive w/ N >= 3 in each panel (dataset)
#	[4]	Only Alive w/ N >= 3 in each panel (summary)
#	[5]	Only Dead w/ N >= 3 in each panel (dataset)
#	[6]	Only Dead w/ N >= 3 in each panel (summary)

### Usage example:
# 
### Input example:
#	[1]	File: August18.2022.BRCA.TSG.gene.corr.panel.summary.txt
#	Gene    Alive.P1        Alive.P2        Alive.P3        Alive.P4        Alive.P5        Alive.P6        Dead.P1 Dead.P2 Dead.P3 Dead.P4      Dead.P5 Dead.P6 Alive.panel.count       Dead.panel.count        Num.com.panel   Alive.CG.total  Dead.CG.total   alive-dead.p1	alive-dead.p2   alive-dead.p3   alive-dead.p4   alive-dead.p5   alive-dead.p6
#	ABCG2   0       0       0       0       1       1       0       0       0       3       0       3       2       2       1       2   60       0       0       -3      1       -2


###########################################################################################
# Input
###########################################################################################
date()

args = c("Summary_Inputs/August18.2022.BRCA.TSG.gene.corr.panel.summary.csv", "Feb15.2025", "BRCA.TSG")

gene.panel.info <- read.table(args[1], header=T, sep=",")
dim(gene.panel.info)
date()

date <- args[2]
date

key.word <- args[3]
key.word

###########################################################################################
# [1] Alive and dead overlap in >= 4 panels, N >= 3
###########################################################################################
# Column 16 contains the number of common panels b/w alive and dead

common.GE4.index <- which(gene.panel.info[,16] >= 4)
length(common.GE4.index)

find.common.info.overlap <- function(panel.vector)
{
	# Gene
	gene <- as.character(panel.vector[1])
	
	# Panels are in common
	panel.names <- c("neg2pos", "pos2neg", "sleeping.neg", "sleeping.pos", "neg.shutting", "pos.shutting")
	alive.panels <- as.numeric(panel.vector[2:7])
	dead.panels <- as.numeric(panel.vector[8:13])
	panels.present.index <- which(alive.panels >= 3 & dead.panels >= 3)
	panels.present.names <- paste(panel.names[panels.present.index], collapse=";", sep="")

	# Panel count
	panel.counts <- as.numeric(panel.vector[16])

	# Alive and dead counts
	alive.counts <- paste(as.numeric(panel.vector[2:7]), collapse=";", sep="")
	dead.counts <- paste(as.numeric(panel.vector[8:13]), collapse=";", sep="")

	# Combine information and output
	overall.output <- c(gene, panels.present.names, panel.counts, alive.counts, dead.counts)
	return(overall.output)
}

common.GE4.unsorted <- t(apply(gene.panel.info[common.GE4.index,], 1, find.common.info.overlap))
dim(common.GE4.unsorted)
common.GE4.unsorted[1:5,]
date()

common.GE4 <- common.GE4.unsorted[order(as.numeric(common.GE4.unsorted[,3]), decreasing=TRUE), ]
dim(common.GE4)
colnames(common.GE4) <- c("Gene", "Panels.present", "Com.panels.count", "Alive.counts", "Dead.counts")
common.GE4[1:5,]

common.GE4.gene.names = matrix(common.GE4[,1], ncol=1)
colnames(common.GE4.gene.names) = "Gene"

write.table(common.GE4.gene.names, file=paste(date, key.word, "methodC.gene.list.csv", sep="."), row.names=FALSE, col.names=TRUE, quote=FALSE, sep=",")

###########################################################################################
# [2]	|Alive - Dead| >= 3 in >= 4 panels (dataset)
###########################################################################################
# Columns 17-22 contain alive - dead for each panel

find.common.info.diff <- function(panel.vector)
{
	# Gene
	gene <- as.character(panel.vector[1])
	
	# Panels are in common
	panel.names <- c("neg2pos", "pos2neg", "sleeping.neg", "sleeping.pos", "neg.shutting", "pos.shutting")
	diff.panels <- as.numeric(panel.vector[17:22])
	alive.panels <- as.numeric(panel.vector[2:7])
	dead.panels <- as.numeric(panel.vector[8:13])
	panels.present.index <- which(abs(diff.panels) >= 3 & alive.panels > 0 & dead.panels > 0)
	panels.present.names <- paste(panel.names[panels.present.index], collapse=";", sep="")

	# Panel count
	panel.counts <- length(panels.present.index)

	# Alive and dead counts
	alive.counts <- paste(as.numeric(panel.vector[2:7]), collapse=";", sep="")
	dead.counts <- paste(as.numeric(panel.vector[8:13]), collapse=";", sep="")
	diff.counts <- paste(as.numeric(panel.vector[17:22]), collapse=";", sep="")

	# Combine information and output
	overall.output <- c(gene, panels.present.names, panel.counts, alive.counts, dead.counts, diff.counts)
	return(overall.output)
}


find.GE3.diff <- function(panel.vector)
{
	alive.panels <- as.numeric(panel.vector[2:7])
	dead.panels <- as.numeric(panel.vector[8:13])
	diff.panels <- as.numeric(panel.vector[17:22])
	GE3.diff.index <- which(abs(diff.panels) >= 3 & alive.panels > 0 & dead.panels > 0)
	GE3.diff.count <- length(GE3.diff.index)
	return(GE3.diff.count)
}

GE3.diff.count <- apply(gene.panel.info, 1, find.GE3.diff)
GE3.diff.GE4.index <- which(GE3.diff.count >= 4)

GE3.diff.GE4.unsorted <- t(apply(gene.panel.info[GE3.diff.GE4.index,], 1, find.common.info.diff))
dim(GE3.diff.GE4.unsorted)
GE3.diff.GE4.unsorted[1:5,]
date()

GE3.diff.GE4 <- GE3.diff.GE4.unsorted[order(GE3.diff.GE4.unsorted[,3], decreasing=TRUE), ]
dim(GE3.diff.GE4)
colnames(GE3.diff.GE4) <- c("Gene", "Panels.present", "Com.panels.count", "Alive.counts", "Dead.counts", "D-A.diff")
GE3.diff.GE4[1:5,]


GE3.diff.GE4.gene.names = matrix(GE3.diff.GE4[,1], ncol=1)
colnames(GE3.diff.GE4.gene.names) = "Gene"

write.table(GE3.diff.GE4.gene.names, file=paste(date, key.word, "methodD.gene.list.csv", sep="."), row.names=FALSE, col.names=TRUE, quote=FALSE, sep=",")

###########################################################################################
# [3-4]	Only Alive w/ N >= 3 in each panel
###########################################################################################
### Extract panel info
find.only.alive <- function(gene.info, panel.num, type)
{
	# Extract name of panel and genes
	panel.names <- c("neg2pos", "pos2neg", "sleeping.neg", "sleeping.pos", "neg.shutting", "pos.shutting")
	panel.name.num <- panel.names[panel.num]
	genes <- as.character(gene.panel.info[,1])

	# Extract counts
	alive.panel <- as.vector(as.numeric(gene.info[,panel.num + 1]))
	dead.panel <- as.vector(as.numeric(gene.info[,panel.num + 7]))

	# Find which genes are only in alive/dead
	if(type == "Alive")
	{
		print("Alive")
		only.index <- which(alive.panel >= 3 & dead.panel == 0)
		only.freq <- alive.panel[only.index]
	} else if(type == "Dead") {
		print("Dead")
		only.index <- which(alive.panel == 0 & dead.panel >= 3)
		only.freq <- dead.panel[only.index]
	} else {
		return(0)
	}

	if(length(only.index) > 1) {
		only.gene <- genes[only.index]
		alive.freq <- alive.panel[only.index]
		dead.freq <- dead.panel[only.index]

		# Sort by frequency
		only.raw <- cbind(only.gene, only.freq, alive.freq, dead.freq)
		only.raw.sorted.all <- (as.matrix(only.raw[order(only.raw[,2], decreasing=TRUE),]))
		only.raw.sorted <- cbind(as.character(only.raw.sorted.all[, 1]), only.raw.sorted.all[, 3], only.raw.sorted.all[, 4])

		# Combine and output
		overall.only <- only.raw.sorted
		colnames(overall.only) <- c(panel.name.num, panel.name.num, panel.name.num)
		return(overall.only)
	} else if(length(only.index) == 1) {
		only.gene <- genes[only.index]
		alive.freq <- alive.panel[only.index]
		dead.freq <- dead.panel[only.index]
		only.raw <- cbind(only.gene, alive.freq, dead.freq)
		overall.only <- only.raw
		colnames(overall.only) <- c(panel.name.num, panel.name.num, panel.name.num)
		return(overall.only)
	} 
}

alive.p1 <- find.only.alive(gene.panel.info, 1, "Alive")
dim(alive.p1)
alive.p2 <- find.only.alive(gene.panel.info, 2, "Alive")
dim(alive.p2)
alive.p3 <- find.only.alive(gene.panel.info, 3, "Alive")
dim(alive.p3)
alive.p4 <- find.only.alive(gene.panel.info, 4, "Alive")
dim(alive.p4)
alive.p5 <- find.only.alive(gene.panel.info, 5, "Alive")
dim(alive.p5)
alive.p6 <- find.only.alive(gene.panel.info, 6, "Alive")
dim(alive.p6)
date()
save.image()

# Extract gene names
alive.gene.names = matrix(c(alive.p1[,1], alive.p2[,1], alive.p3[,1], alive.p4[,1], alive.p5[,1], alive.p6[,1]), ncol=1)
alive.gene.names


### Output
colnames(alive.gene.names) = "Gene"

write.table(alive.gene.names, file=paste(date, key.word, "methodA.gene.list.csv", sep="."), row.names=FALSE, col.names=TRUE, quote=FALSE, sep=",")

###########################################################################################
# [5-6]	Only Dead w/ N >= 3 in each panel
###########################################################################################
### Extract panel info
dead.p1 <- find.only.alive(gene.panel.info, 1, "Dead")
dead.p2 <- find.only.alive(gene.panel.info, 2, "Dead")
dead.p3 <- find.only.alive(gene.panel.info, 3, "Dead")
dead.p4 <- find.only.alive(gene.panel.info, 4, "Dead")
dead.p5 <- find.only.alive(gene.panel.info, 5, "Dead")
dead.p6 <- find.only.alive(gene.panel.info, 6, "Dead")
date()

# Extract gene names
dead.gene.names = matrix(c(dead.p1[,1], dead.p2[,1], dead.p3[,1], dead.p4[,1], dead.p5[,1], dead.p6[,1]), ncol=1)
dead.gene.names


### Output
colnames(dead.gene.names) = "Gene"

write.table(dead.gene.names, file=paste(date, key.word, "methodB.gene.list.csv", sep="."), row.names=FALSE, col.names=TRUE, quote=FALSE, sep=",")


