###########################################################################################################
# File: /home/udb4/R.code/Correlation/Jan12.2022.co.methylation.M.Spearman.R
###########################################################################################################
##### Purpose:
# Creates correlation matrices for grouped data using M-values and Spearman method
# Creates output1 to allow for easy analysis
# Creates summary tables

##### Notes:
# Run once for each data type (alive normal, alive tumor, dead normal, dead tumor)

##### Usage:
# nohup R CMD BATCH '--args /home/udb4/Data/Oct22.2021.Data/T4.Oct22.2021.BRCA.TSG.19200cg.14col.meth.status.txt BRCA.TSG Jan5.2021' /home/udb4/R.code/Methylation.status/Dec30.2021.gene.type.DM.meth.state.freq.R Jan5.Rout

##### Input:
#	[1]	data of alive only DM sites
#	[2] 	data of all other CG sites than alive only DM sites
#	[3]	data of dead only DM sites
#	[4] 	data of all other CG sites than dead only DM sites
#	[5]	data of overlapping DM sites
#	[6] 	data of all other CG sites than overlapping DM sites

##### Output:
#	[1] 	Correlation matrices
#			alive DM * alive DM, alive DM * non alive DM
#			dead DM * dead DM, dead DM * non dead DM
#			overlap DM * overlap DM, overlap DM * non overlap DM
#	[2] 	Output 1
#			alive DM * alive DM, alive DM * non alive DM
#			dead DM * dead DM, dead DM * non dead DM
#			overlap DM * overlap DM, overlap DM * non overlap DM
#	[3] 	Table 1
#	[4] 	Table 2
#	[5]	Table 3

##### Usage example:

##### Input example:
# [1-6] (all have same format, just different CG sites) 
# Example file: /home/udb4/Results/Gene.type.analysis/August24.2021/August31.BRCA.TSG.tumor.alive.A.nonDM.data.txt
#	Composite.Element.REF   Chromosome      Start   End     T1      T2      T3     T4       T5      T6      T7      T8      T9      T10     T11     T12     T13    T14      T15     T16     T17     T18     T19     T20     T21     T22     T23    T24      T25     T26     T27     T28     T29     T30     T31     T32     T33    T34      T35     T36     T37     T38     T39     T40     T41     T42     T43    T44      T45     T46     T47     T48     T49     T50     T51     T52     T53    Min      Q1      Median  Mean    Q3      Max     NAcount st.dev  diff.Q3Q1      outliers.coef2   outliers.coef3
#	cg00000029      chr16   53434200        53434201        0.1189263       0.4550815       0.0917992       0.2430791       0.0679704       0.0770957       0.0850158       0.2697059       0.1730189       0.1739928       0.3570401       0.1277842       0.2974817       0.4908009       0.5030071       0.5338446       0.7165011       0.133163        0.1461256       0.3727657       0.400039        0.1132871       0.1252165       0.3117692       0.1828558       0.1856318       0.1308976       0.1633663       0.5057104       0.3774468       0.2319982       0.2739286       0.1672998       0.1224545       0.140423        0.1846421       0.1623975       0.2368054       0.1118333       0.1163632       0.1622039       0.0977877       0.1775547       0.1794641       0.1719714       0.3300061       0.2385852       0.1532707       0.2135176       0.0933888       0.3027547       0.1798427       0.1987051       0.0679704       0.1308976       0.1794641       0.2297664       0.2974817       0.7165011       0       0.139381850707599       0.166584116402623       1       0


##### Output example:
# [1] Correlation matrices
# [2] Output 1
# [3] Table 1
# [4] Table 2
# [5] Table 3

################################################################################
# Load required functions
################################################################################
# Remove anything still in workspace to save space
rm(list = ls())

source("/home/udb4/R.code/Correlation/July19.2021.create.output1.R")
# function: create.output1(corr.matrix, DM.info, all.CG.info)
#	returns: data frame of output1

source("/home/udb4/R.code/Correlation/July19.2021.create.tables.R")
# function1: create.table1(DM.DM.output1, DM.nonDM.output1, nonDM.corr.matrix)
#	returns: matrix of table 1 summary
# function2: create.table2(DM.DM.output1, DM.nonDM.output1, nonDM.corr.matrix)
#	returns: matrix of table 2 summary
# function3: create.table3(DM.DM.output1, DM.nonDM.output1, nonDM.corr.matrix)
#	reutnrs: matrix of table 3 summary	


###########################################################################################################
# Define input
###########################################################################################################
date()
args <- commandArgs(trailingOnly = TRUE)

alive.DM.data <- read.table(args[1], header=T, sep="\t")
dim(alive.DM.data)
date()

alive.nonDM.data <- read.table(args[2], header=T, sep="\t")
dim(alive.nonDM.data)
date()

dead.DM.data <- read.table(args[3], header=T, sep="\t")
dim(dead.DM.data)
date()

dead.nonDM.data <- read.table(args[4], header=T, sep="\t")
dim(dead.nonDM.data)
date()

overlap.DM.data <- read.table(args[5], header=T, sep="\t")
dim(overlap.DM.data)
date()

overlap.nonDM.data <- read.table(args[6], header=T, sep="\t")
dim(overlap.nonDM.data)
date()

key.word <- args[7]
key.word

date <- args[8]
date

################################################################################
# 1. Create correlation matrices
################################################################################
# Find number of columns in data
n.alive <- dim(alive.DM.data)[2]	# number of columns in alive datasets
n.alive
n.dead <- dim(dead.DM.data)[2]		# number of column in dead datasets
n.dead
n.overlap <- dim(overlap.DM.data)[2]
n.overlap
date()

# Extract numerical data to use in correlation matrices, and transpose data
alive.DM.t.b <- as.matrix(t(alive.DM.data[,5:(n.alive-11)]))
alive.nonDM.t.b <- as.matrix(t(alive.nonDM.data[,5:(n.alive-11)]))
dead.DM.t.b <- as.matrix(t(dead.DM.data[,5:(n.dead-11)]))
dead.nonDM.t.b <- as.matrix(t(dead.nonDM.data[,5:(n.dead-11)]))
overlap.DM.t.b <- as.matrix(t(overlap.DM.data[,5:(n.overlap-11)]))
overlap.nonDM.t.b <- as.matrix(t(overlap.nonDM.data[,5:(n.overlap-11)]))
date()

# Preform m-value transformation
# Equation to use: m = log2 ( beta / (1 - beta) )
alive.DM.t <- log2(alive.DM.t.b / (1 - alive.DM.t.b) )
alive.nonDM.t <- log2(alive.nonDM.t.b / (1 - alive.nonDM.t.b) )
dead.DM.t <- log2(dead.DM.t.b / (1 - dead.DM.t.b) )
dead.nonDM.t <- log2(dead.nonDM.t.b / (1 - dead.nonDM.t.b) )
overlap.DM.t <- log2(overlap.DM.t.b / (1 - overlap.DM.t.b) )
overlap.nonDM.t <- log2(overlap.nonDM.t.b / (1 - overlap.nonDM.t.b) )

# Create correlation matrices
alive.DM.corr <- trunc( cor(alive.DM.t, alive.DM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(alive.DM.corr)
dim(alive.DM.corr)
date()
alive.nonDM.corr <- trunc( cor(alive.DM.t, alive.nonDM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(alive.nonDM.corr)
dim(alive.nonDM.corr)
date()

dead.DM.corr <- trunc( cor(dead.DM.t, dead.DM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(dead.DM.corr)
dim(dead.DM.corr)
date()
dead.nonDM.corr <- trunc( cor(dead.DM.t, dead.nonDM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(dead.nonDM.corr)
dim(dead.nonDM.corr)
date()

overlap.DM.corr <- trunc( cor(overlap.DM.t, overlap.DM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(overlap.DM.corr)
dim(overlap.DM.corr)
date()
overlap.nonDM.corr <- trunc( cor(overlap.DM.t, overlap.nonDM.t, use="pairwise.complete.obs", method="spearman")*(10^5) ) / (10^5)
class(overlap.nonDM.corr)
dim(overlap.nonDM.corr)
date()

# Output correlation matrices
data.types <- c("A.DM", "A.nonDM", "D.DM", "D.nonDM", "O.DM", "O.nonDM")
corr.data.names <- paste(date, key.word, data.types, "corr.matrix.txt", sep=".")
corr.data.names
write.table(alive.DM.corr, file=corr.data.names[1], row.names=T, col.names=T, quote=F, sep="\t")
write.table(alive.nonDM.corr, file=corr.data.names[2], row.names=T, col.names=T, quote=F, sep="\t")
write.table(dead.DM.corr, file=corr.data.names[3], row.names=T, col.names=T, quote=F, sep="\t")
write.table(dead.nonDM.corr, file=corr.data.names[4], row.names=T, col.names=T, quote=F, sep="\t")
write.table(overlap.DM.corr, file=corr.data.names[5], row.names=T, col.names=T, quote=F, sep="\t")
write.table(overlap.nonDM.corr, file=corr.data.names[6], row.names=T, col.names=T, quote=F, sep="\t")

################################################################################
# 3. Create output1 for each correlation matrix
################################################################################
alive.DM.output1 <- create.output1(alive.DM.corr, alive.DM.data[,1:4], alive.DM.data[,1:4])
alive.DM.output1[1:2,]
dim(alive.DM.output1)
date()
alive.nonDM.output1 <- create.output1(alive.nonDM.corr, alive.DM.data[,1:4], alive.nonDM.data[,1:4])
alive.nonDM.output1[1:2,]
dim(alive.nonDM.output1)
date()

dead.DM.output1 <- create.output1(dead.DM.corr, dead.DM.data[,1:4], dead.DM.data[,1:4])
dead.DM.output1[1:2,]
dim(dead.DM.output1)
date()
dead.nonDM.output1 <- create.output1(dead.nonDM.corr, dead.DM.data[,1:4], dead.nonDM.data[,1:4])
dead.nonDM.output1[1:2,]
dim(dead.nonDM.output1)
date()

overlap.DM.output1 <- create.output1(overlap.DM.corr, overlap.DM.data[,1:4], overlap.DM.data[,1:4])
overlap.DM.output1[1:2,]
dim(overlap.DM.output1)
date()
overlap.nonDM.output1 <- create.output1(overlap.nonDM.corr, overlap.DM.data[,1:4], overlap.nonDM.data[,1:4])
overlap.nonDM.output1[1:2,]
dim(overlap.nonDM.output1)
date()

# Output output1
output1.names <- paste(date, key.word, data.types, "output1.txt", sep=".")
output1.names
write.table(alive.DM.output1, file=output1.names[1], row.names=F, col.names=T, quote=F, sep="\t")
write.table(alive.nonDM.output1, file=output1.names[2], row.names=F, col.names=T, quote=F, sep="\t")
write.table(dead.DM.output1, file=output1.names[3], row.names=F, col.names=T, quote=F, sep="\t")
write.table(dead.nonDM.output1, file=output1.names[4], row.names=F, col.names=T, quote=F, sep="\t")
write.table(overlap.DM.output1, file=output1.names[5], row.names=F, col.names=T, quote=F, sep="\t")
write.table(overlap.nonDM.output1, file=output1.names[6], row.names=F, col.names=T, quote=F, sep="\t")

################################################################################
# 3. Create table summaries
################################################################################
###### Table 1
# Find row information for alive and dead data
alive.table1 <- create.table1(alive.DM.output1, alive.nonDM.output1, alive.nonDM.corr)
date()
dead.table1 <- create.table1(dead.DM.output1, dead.nonDM.output1, dead.nonDM.corr)
date()
overlap.table1 <- create.table1(overlap.DM.output1, overlap.nonDM.output1, overlap.nonDM.corr)
date()

# Bind together information
table1.overall <- rbind(overlap.table1, alive.table1, dead.table1)
dim(table1.overall)
table.row.names <- paste(key.word, c("O.DM", "A.DM", "D.DM"))
rownames(table1.overall) <- table.row.names
colnames(table1.overall) <- c("num.DM.sites", "num.pairs", "num.high.corr", "prop.high.corr")
date()

###### Table 2
# Find row information
alive.table2 <- create.table2(alive.DM.output1, alive.nonDM.output1, alive.nonDM.corr)
date()
dead.table2 <- create.table2(dead.DM.output1, dead.nonDM.output1, dead.nonDM.corr)
date()
overlap.table2 <- create.table2(overlap.DM.output1, overlap.nonDM.output1, overlap.nonDM.corr)
date()

# Bind together information
table2.overall <- rbind(overlap.table2, alive.table2, dead.table2)
dim(table2.overall)
rownames(table2.overall) <- table.row.names
colnames(table2.overall) <- c("min", "Q1", "median", "mean", "Q3", "max")
date()

###### Table 3
# Find row information
alive.table3 <- create.table3(alive.DM.output1, alive.nonDM.output1, alive.nonDM.corr)
dead.table3 <- create.table3(dead.DM.output1, dead.nonDM.output1, dead.nonDM.corr)
overlap.table3 <- create.table3(overlap.DM.output1, overlap.nonDM.output1, overlap.nonDM.corr)

# Bind together information
table3.overall <- rbind(overlap.table3, alive.table3, dead.table3)
dim(table3.overall)
rownames(table3.overall) <- table.row.names
colnames(table3.overall) <- c("num.pairs", "num.same.chr", "num.diff.chr", "num.neg", "num.pos")

##### Output tables
table.names.csv <- paste(date, key.word, "table", 1:3, "summary.csv", sep=".")
table.names.csv
write.table(table1.overall, file=table.names.csv[1], row.names=T, col.names=T, quote=F, sep=",")
write.table(table2.overall, file=table.names.csv[2], row.names=T, col.names=T, quote=F, sep=",")
write.table(table3.overall, file=table.names.csv[3], row.names=T, col.names=T, quote=F, sep=",")

table1.overall
table2.overall
table3.overall




