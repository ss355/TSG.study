#############################################
# Aug12.only.alive.or.dead.gene.compare.stats.R
#############################################

args=commandArgs(TRUE)
`%notin%` = Negate(`%in%`)

################################
# Finds genes that only occur in alive or dead with freq >=freq.min
only.dead.or.alive = function(alive.panel, dead.panel, panel.type, alive.dead, freq.min){
  
  if (alive.dead=='Alive'){
    genes.in.one=setdiff(alive.panel[,1], dead.panel[,1])
    genes.in.one.counts=alive.panel[alive.panel[,1] %in% genes.in.one, ]
  }
  else{
    genes.in.one=setdiff(dead.panel[,1], alive.panel[,1])
    genes.in.one.counts=dead.panel[dead.panel[,1] %in% genes.in.one, ]
  }
  
  genes.large.freq = genes.in.one.counts[which(genes.in.one.counts[,2]>=freq.min), ]
  
  return(genes.large.freq)
}

################################
# Reading in data
# R CMD BATCH '--args nonTSG.gene.lists/Aug12.2022.neg2pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.pos2neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.neg.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.pos.alive.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.neg2pos.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.pos2neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.shutting.pos.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.neg.dead.overlap.nonTSG.gene.list.csv nonTSG.gene.lists/Aug12.2022.sleeping.pos.dead.overlap.nonTSG.gene.list.csv Aug12.2022 nonTSG.Overlap' /home/c_t370/REU.2021/Code/8x8/Aug12.only.alive.or.dead.gene.compare.stats.R /home/c_t370/REU.2021/Output/8x8/sleeping.shutting/TSG.Overlap.Only.Alive.or.Dead/Aug12.nonTSG.only.dead.or.alive.common.Rout
# R CMD BATCH '--args TSG.only.gene.lists/Aug5.only.TSG.neg2pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.pos2neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.neg.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.pos.genes.alive.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.neg2pos.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.pos2neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.shutting.pos.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.neg.genes.dead.overlap.csv TSG.only.gene.lists/Aug5.only.TSG.sleeping.pos.genes.dead.overlap.csv Aug12.2022 onlyTSG.overlap' /home/c_t370/REU.2021/Code/8x8/Aug12.only.alive.or.dead.gene.compare.stats.R /home/c_t370/REU.2021/Output/8x8/sleeping.shutting/TSG.Overlap.Only.Alive.or.Dead/Aug12.onlyTSG.only.dead.or.alive.common.Rout

alive.neg2pos=read.csv(args[1], header=TRUE)
dim(alive.neg2pos)

alive.pos2neg=read.csv(args[2], header=TRUE)
dim(alive.pos2neg)

alive.shutting.neg=read.csv(args[3], header=TRUE)
dim(alive.shutting.neg)

alive.shutting.pos=read.csv(args[4], header=TRUE)
dim(alive.shutting.pos)

alive.sleeping.neg=read.csv(args[5], header=TRUE)
dim(alive.sleeping.neg)

alive.sleeping.pos=read.csv(args[6], header=TRUE)
dim(alive.sleeping.pos)

dead.neg2pos=read.csv(args[7], header=TRUE)
dim(dead.neg2pos)

dead.pos2neg=read.csv(args[8], header=TRUE)
dim(dead.pos2neg)

dead.shutting.neg=read.csv(args[9], header=TRUE)
dim(dead.shutting.neg)

dead.shutting.pos=read.csv(args[10], header=TRUE)
dim(dead.shutting.pos)

dead.sleeping.neg=read.csv(args[11], header=TRUE)
dim(dead.sleeping.neg)

dead.sleeping.pos=read.csv(args[12], header=TRUE)
dim(dead.sleeping.pos)

date=args[13]
print(date)

type=args[14]
print(type)

for (freq in 3:5){
  print(paste('Freq: ', freq))
  print('Alive')
  only.alive.neg2pos=only.dead.or.alive(alive.neg2pos, dead.neg2pos, 'neg2pos', 'Alive', freq)
  print(dim(only.alive.neg2pos))
  only.alive.pos2neg=only.dead.or.alive(alive.pos2neg, dead.pos2neg, 'pos2neg', 'Alive', freq)
  print(dim(only.alive.pos2neg))
  only.alive.sleeping.neg=only.dead.or.alive(alive.sleeping.neg, dead.sleeping.neg, 'sleeping.neg', 'Alive', freq)
  print(dim(only.alive.sleeping.neg))
  only.alive.sleeping.pos=only.dead.or.alive(alive.sleeping.pos, dead.sleeping.pos, 'sleeping.pos', 'Alive', freq)
  print(dim(only.alive.sleeping.pos))
  only.alive.shutting.neg=only.dead.or.alive(alive.shutting.neg, dead.shutting.neg, 'shutting.neg', 'Alive', freq)
  print(dim(only.alive.shutting.neg))
  only.alive.shutting.pos=only.dead.or.alive(alive.shutting.pos, dead.shutting.pos, 'shutting.pos', 'Alive', freq)
  print(dim(only.alive.shutting.pos))

  print('Dead')
  only.dead.neg2pos=only.dead.or.alive(alive.neg2pos, dead.neg2pos, 'neg2pos', 'Dead', freq)
  print(dim(only.dead.neg2pos))
  only.dead.pos2neg=only.dead.or.alive(alive.pos2neg, dead.pos2neg, 'pos2neg', 'Dead', freq)
  print(dim(only.dead.pos2neg))
  only.dead.sleeping.neg=only.dead.or.alive(alive.sleeping.neg, dead.sleeping.neg, 'sleeping.neg', 'Dead', freq)
  print(dim(only.dead.sleeping.neg))
  only.dead.sleeping.pos=only.dead.or.alive(alive.sleeping.pos, dead.sleeping.pos, 'sleeping.pos', 'Dead', freq)
  print(dim(only.dead.sleeping.pos))
  only.dead.shutting.neg=only.dead.or.alive(alive.shutting.neg, dead.shutting.neg, 'shutting.neg', 'Dead', freq)
  print(dim(only.dead.shutting.neg))
  only.dead.shutting.pos=only.dead.or.alive(alive.shutting.pos, dead.shutting.pos, 'shutting.pos', 'Dead', freq)
  print(dim(only.dead.shutting.pos))
  
  write.table(only.alive.neg2pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.neg2pos.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.alive.pos2neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.pos2neg.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.alive.sleeping.neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.sleeping.neg.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.alive.sleeping.pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.sleeping.pos.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.alive.shutting.neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.shutting.neg.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.alive.shutting.pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.shutting.pos.only.alive.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.neg2pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.neg2pos.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.pos2neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.pos2neg.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.sleeping.neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.sleeping.neg.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.sleeping.pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.sleeping.pos.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.shutting.neg, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.shutting.neg.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  write.table(only.dead.shutting.pos, paste('TSG.Overlap.Only.Alive.or.Dead/', date,'.', type, '.shutting.pos.only.dead.genes.freq', freq, '.csv', sep=''), sep=',', row.names=FALSE)
  
}